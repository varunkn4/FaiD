import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Home extends Component {
    render(){
        return(
            <p>Hi Admin, Welcome to FaiD!!</p>
        );
    }
}

export default Home;